import React from 'react';

const Onboard = () => {
    return (
        <div>
            <h1>Tenant Onboarding</h1>
            <p>Manage tenant onboarding here.</p>
        </div>
    );
};

export default Onboard;